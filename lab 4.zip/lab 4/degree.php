<form action ="#" method="POST">
  
  <fieldset>
  <legend>DEGREE </legend>
  <input type="checkbox" name="degree" value="<?php if(($_POST['degree'])){echo $_POST['degree'];}?>  ">SSC
  <input type="checkbox" name="degree" value="<?php if(($_POST['degree'])){echo $_POST['degree'];}?>  ">HSC
  <input type="checkbox" name="degree" value="<?php if(($_POST['degree'])){echo $_POST['degree'];}?>  ">BSc
  <input type="checkbox" name="degree" value="<?php if(($_POST['degree'])){echo $_POST['degree'];}?>  ">MSc
  

  
  <br/> <br/>
  
  
  
  
  <input type="submit" name="submit" value="submit">
  <hr/>
 
 </fieldset>

 </form>