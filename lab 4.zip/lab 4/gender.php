<?php error_reporting(0);


?>


<form action ="#" method="POST">
  <fieldset>
  <legend>GENDER </legend>
  <input type="radio" name="gender" value="<?php if(($_POST['gender']=="male)){echo "checked";}?>>male
   <input type="radio" name="gender" value="<?php if(($_POST['gender']=="female)){echo "checked";}?>>female
	 <input type="radio" name="gender" value="<?php if(($_POST['gender']=="other)){echo "checked";}?>>other
  <input type="submit" name="submit" value="submit">
  <hr/>
  </fieldset>

 </form>