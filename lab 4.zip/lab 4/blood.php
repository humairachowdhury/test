<?php error_reporting(0)

?>

<form action ="#" method="POST">
  <fieldset>
  <legend>BLOOD GROUP </legend>
  <select name="BLOOD GROUP">
  
 
  
 <option value ="A+"<?php if(($_POST['BLOOD GROUP']=="A+")){echo "checked";}?>">A+</option>
  <option value ="A-"<?php if(($_POST['BLOOD GROUP']=="A-")){echo "checked";}?>">A-</option>
   <option value ="B+"<?php if(($_POST['BLOOD GROUP']=="B+")){echo "checked";}?>">B+</option>
    <option value ="AB+"<?php if(($_POST['BLOOD GROUP']=="AB+")){echo "checked";}?>">AB+</option>
  </select>
    <hr/>
  <input type="submit" name="submit" value="submit">

  </fieldset>

 </form>
 