<?php error_reporting(0);

$minday=1;
$maxday=31;
$minmonth=1;
$maxmonth=12;
$minyear=1953;
$maxyear=1998;

if(($_POST["day"] >= $minday )&&($_POST["day"] <= $maxday ))
{
    if(($_POST["month"] >= $minmonth )&&($_POST["month"] <= $maxmonth ))
    {
        if(($_POST["year"] >= $minyear )&&($_POST["year"] <= $maxyear ))
        {
            echo "submitted";
        }
        else
            echo "wrong";
    }
    else
        echo "wrong";
}
else
    echo "wrong";

?>
    
<form action="#" method="post">
	<fieldset>
		<legend>DOB</legend>
		
		dd
		<input type="text" name="day" value="" style="width:30px">
		mm
		<input type="text" name="month" value="" style="width:30px">
		yy
		<input type="text" name="year" value="" style="width:40px">
		<br/>
		
		<input type="submit" name="submit" value="Submit">
	</fieldset>
</form>


