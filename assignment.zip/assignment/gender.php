<?php 
if(!isset($_POST['gender'])){echo "Please select one";}
else
    echo "submitted";
?>
<form action="#" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<input style="width:30px" type="radio" name="gender[]" value="male">male
		<input style="width:30px" type="radio" name="gender[]" value="female">female
		<input style="width:30px" type="radio" name="gender[]" value="other">other
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>